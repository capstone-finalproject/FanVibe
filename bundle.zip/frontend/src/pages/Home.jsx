export default function HomePage() {
  return <>
    <h1>Home</h1>
    <p>Put something interesting here!</p>
  </>;
}
