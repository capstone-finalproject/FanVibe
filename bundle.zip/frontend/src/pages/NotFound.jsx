export default function NotFoundPage() {
  return <>
    <h1>Not Found</h1>
  </>;
}
