const User = require('./user');

global.User = User;
